
#include "rs485_task.h"
#include "log/bsp_log.h"
#include "led/bsp_led.h"
#include "rs485/bsp_rs485.h"
#include "TimBase/bsp_TiMbase.h"
#include "mbslave/bsp_mbslave.h"

void RS485_Error_Repose(u8 *data)
{
    uint16_t crc = 0;
    uint16_t TxCount = 0;

    RS485_TX_BUF[TxCount++] = data[0];		/* ��վ��ַ */
    RS485_TX_BUF[TxCount++] = data[1]|0x80; /* ������ */
    RS485_TX_BUF[TxCount++] = data[1];	    /* �Ĵ�����ַ ���ֽ� */

    crc = MB_CRC16((uint8_t*)&RS485_TX_BUF, TxCount);
    RS485_TX_BUF[TxCount++] = crc;	          /* crc ���ֽ� */
    RS485_TX_BUF[TxCount++] = crc>>8;		  /* crc ���ֽ� */
    RS485_Send_Data((uint8_t *)&RS485_TX_BUF, TxCount);
}

void rs485_task(void)
{
    if((RS485_COUNT&0x80))      //���յ�������һ֡����
    {
        if(RS485_RX_BUF[0] != MB_SLAVEADDR) //�ӻ���ַ����
        {
            memset(RS485_RX_BUF, 0, sizeof(RS485_RX_BUF));
            RS485_COUNT = 0;
            return ;
        }
        
        uint16_t crc_s = 0;
        uint16_t crc_c = 0;
        uint16_t RxCount = RS485_COUNT&0x7F;
        crc_c = MB_CRC16((uint8_t*)&RS485_RX_BUF, RxCount-2);
        crc_s = ((RS485_RX_BUF[RxCount-1]<<8) | RS485_RX_BUF[RxCount-2]);
        
        if(crc_c == crc_s) 
        {
            MB_Parse_Data();
            uint8_t Ex_code = MB_Analyze_Execute();     /* ��������֡��ִ�� */   
            if(Ex_code !=EX_CODE_NONE)                  /* �����쳣 */
            {
                MB_Exception_RSP(PduData.Code, Ex_code);
            }
            else
            {
                MB_RSP(PduData.Code);
            }
        }
        
        memset(RS485_RX_BUF, 0, sizeof(RS485_RX_BUF));
        RS485_COUNT = 0;
    }
}
