
#ifndef __BSP_TIMEBASE_H
#define __BSP_TIMEBASE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sys.h"

void TIM5_Init(u16 arr,u16 psc);

#ifdef __cplusplus
extern "C" {
#endif

#endif	


